<?php

	session_start();

	if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
	}
	require_once "config.php";

	$sql = "select * from booking where username = ?";
	$stmt = mysqli_prepare($link, $sql);
	$stmt->bind_param("s", $_SESSION['username']);

	$bookings = null;
	$book = null;

?>
<html>
<head>
	<meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
	body{ font: 14px sans-serif; text-align: center; }

	.navbar {
	  overflow: hidden;
	  background-color: #333;
	}

	.navbar a {
	  float: left;
	  font-size: 16px;
	  color: white;
	  text-align: center;
	  padding: 14px 16px;
	  text-decoration: none;
	}

	.subnav {
	  float: left;
	  overflow: hidden;
	}

	.subnav .subnavbtn {
	  font-size: 16px;
	  border: none;
	  outline: none;
	  color: white;
	  padding: 14px 16px;
	  background-color: inherit;
	  font-family: inherit;
	  margin: 0;
	}

	.navbar a:hover, .subnav:hover .subnavbtn {
	  background-color: red;
	}

	.subnav-content {
	  display: none;
	  position: absolute;
	  left: 0;
	  background-color: red;
	  width: 100%;
	  z-index: 1;
	}

	.subnav-content a {
	  float: left;
	  color: white;
	  text-decoration: none;
	}

	.subnav-content a:hover {
	  background-color: #eee;
	  color: black;
	}

	.subnav:hover .subnav-content {
	  display: block;
	}

	th {
		background-color:#000;
		color:white;
	}

	td, th {
		padding:5px;
		border:1px solid #000;
	}

    </style>
</head>
<body>
	<div class="page-header">
		<h2>Welcome to NRAB <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Here is your calander.</h2>
	</div>

	<div class="navbar">
	  <!--<a href="welcome.php">Home</a>-->
	  <a href="bookRoom.php">Book a room</a>
	  <a href="myAccount.php">My Account</a>
	</div>

	<div align='centre'>
		&nbsp
		<!--<label><?php echo htmlspecialchars($_SESSION["username"]);?>'s bookings</label>-->

	</div>

	<?php
	try {
		if($stmt->execute()) {
			$stmt->store_result();
			$variables = array();
			$data = array();
			$meta = $stmt->result_metadata();
			while($field = $meta->fetch_field()) {
				$variables[] = &$data[$field->name];
			}
			call_user_func_array(array($stmt, 'bind_result'), $variables);
			$i = 0;
			while($stmt->fetch()) {
				$bookings[$i] = array();
				$book[$i] = array();
				foreach($data as $k=>$v) {
					$bookings[$i][$k] = $v;
					$book[$i] = json_encode($bookings[$i]);
					$book[$i] = json_decode($book[$i], true);
				}

				$i++;
			}
			if(is_array($book) || is_object($book)) {
				echo "<table style='border:1px solid black; margin-left:auto; margin-right:auto; width:900px;'>
					<tr>
							<th> <font face='Arial'><b>Booking date</b></font> </th>
							<th> <font face='Arial'><b>Start time</b></font> </th>
							<th> <font face='Arial'><b>End time</b></font> </th>
							<th> <font face='Arial'><b>University</b></font> </th>
							<th> <font face='Arial'><b>Room</b></font> </th>
					</tr>";
				foreach($book as $key => $val) {
					echo '<tr>
						<td>'.date('d-M-Y', strtotime($val['bookingDate'])).'</td>
						<td>'.date('g:i A', strtotime($val['startTime'])).'</td>
						<td>'.date('g:i A', strtotime($val['endTime'])).'</td>
						<td>'.$val["uni"].'</td>
						<td>'.$val["room"].'</td>
						</tr>';
				}
			} else {
				echo "<h2>No bookings Avaliable. Go to BookRoom to book a room!</h2>";
			}
			$stmt->close();
		}
	} catch(Exception $e) {
		$bookings = false;
	}

	// Close connection
	mysqli_close($link);
	?>

</body>
</html>
