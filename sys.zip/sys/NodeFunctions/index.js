var app = require('express')();
var http = require('http').createServer(app);
var io = require('socket.io')(http);
var mysql = require('mysql');
var con = mysql.createConnection({
  host: "localhost",
  user: "me",
  password: "password",
  database: "login"
});

app.get('/', function(req, res){
  res.sendFile(__dirname + '/index.html');
});

http.listen(3000, function(){
  console.log('listening on *:3000');
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");

  io.on('connection', function(socket){
    console.log('a user connected');

    socket.on('rooms check', function(room, date, start, end) {
      //DO SQL INSERTS/ALTER TABLES
      var sql = "SELECT room FROM booking where (room = ? and bookingDate = ?) and (startTime >= ? or endTime <= ?)";
      con.query(sql, [room, date, start, end], function (err, result, fields) {
        if (err) throw err;
        console.log(room + " " + date + " " + start + " " + end);
        console.log(result);

        if(result.length == 0) {
          console.log("inserting");
          sql = "INSERT INTO roomCheck VALUES(?)";
          con.query(sql, [room], function(err, result) {
            if(err) throw err;
            console.log("Inserted");
          });
          socket.emit("room", "Room " + room + " is not booked. Please finalize this form and book the room");
        } else {
          console.log(result.length + " results found");
          socket.emit("room", "Room " + room + " is booked between these time slots. Please chose a different room or a different time");
        }
      });
    });

    socket.on("createTmp", function(socket) {
      dropTmp();
      var sql = "CREATE TABLE roomCheck (bookedRoom char(4), PRIMARY KEY(bookedRoom))";
      con.query(sql, function(err, result) {
        if(err) throw err;
        console.log("created");
      });
    });

    socket.on("clearRoomTemp", function(socket) {

    });

    socket.on("updatePassword", function(username, password) {
      var sql = "UPDATE users SET password = ? WHERE username = ?"
      con.query(sql, [password, username], function(err, result) {
        if(err) throw err;
        console.log("updated");
      })
    });

    socket.on('disconnect', function(socket){
      //closeCon();
      var sql = "DROP TABLE IF EXISTS roomCheck";
      con.query(sql, function(err, result) {
        if(err) throw err;
        console.log("deleted");
      });
      console.log("disconnected");
    });
  });
});

function dropTmp() {
  var sql = "DROP TABLE IF EXISTS roomCheck";
  con.query(sql, function(err, result) {
    if(err) throw err;
    console.log("deleted");
  });
  console.log("disconnected");
}

/*function closeCon() {
  con.end(function(err) {
    if (err) {
      return console.log('error:' + err.message);
    }
    console.log('Closed the database connection.');
  });
}*/
