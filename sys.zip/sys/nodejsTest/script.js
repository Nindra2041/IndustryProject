const express = require('express');
const mysql = require('mysql');
var io = require('socket.io').listen(80);

io.sockets.on('connection', function (socket) {
  socket.emit('news', { hello: 'world' }); // Send data to client

  // wait for the event raised by the client
  socket.on('my other event', function (data) {
    console.log(data);
  });
});

var con = mysql.createConnection( {
	host: 'localhost',
	user: 'me',
	password: 'password'
	//database: 'login'
});

con.connect(function(err) {
	if(err) {
		console.log("error");
	} else {
		console.log("connected");
	}
});

con.end((err) => {
  // The connection is terminated gracefully
  // Ensures all previously enqueued queries are still
  // before sending a COM_QUIT packet to the MySQL server.
});

function test() {
	console.log("helloo");
}

test();
