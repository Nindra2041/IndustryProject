<?php

	session_start();

	if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
		header("location: login.php");
		exit;
	}
	require_once "config.php";
	
	$date = "";
	$date_err = "";
		
	$stime = "";
	$startTime = "";
	$startTime_err = "";
		
	$etime = "";
	$endTime = "";
	$endTime_err = "";
		
	$uni = "";
	$uni_err = "";
	
	$room = "";
	$room_err = "";
	
	$msg = "";
	
	if($_SERVER["REQUEST_METHOD"] == "POST"){
 
		if(empty($_POST["date"])){
			$date_err = "Please enter date of booking.";
		} else{
			$date = date('Y-m-d', strtotime($_POST['date']));
		}
		
		if($_POST["start"] == "" && $_POST["end"] == "") {//both empty 
			$startTime_err = "Please enter start and end times for your booking";
		//check if each variable has a value
		} else { 
			if($_POST["start"] == ""){//start is empty, end has a value
				$startTime_err = "Please enter start time of booking.";
			} else {
				$stime = $_POST['start'];
				$startTime = "$date $stime";
			}
			//end is empty, start has a value
			if($_POST["end"] == ""){
				$endTime_err = "Please enter end time of booking.";
			} else{
				$etime = $_POST['end'];
				$endTime = "$date $etime";
			}
		} 
		
		if($_POST["uni"] == ""){
			$uni_err = "Please enter the university.";
		} else{
			$uni = $_POST['uni'];
		}
		
		if($_POST["room"] == "") {
			echo $room_err = "Please choose a room";
		} else {
			$room = $_POST["room"];
			echo $room;
		}
		
		// Validate credentials
		if(empty($date_err) && empty($startTime_err) && empty($endTime_err) && empty($uni_err)){
			// Prepare a select statement
			$sql = "insert into booking values(?, ?, ? ,?, ?)";
			$stmt = mysqli_prepare($link, $sql);
			$stmt->bind_param("sssss", $_SESSION['username'], $date, $startTime, $endTime, $uni);

			if($stmt->execute()){
				$msg = "Room booked.";
			} else{
				$msg = "ERROR: room could not be booked, there is already a room booked in this time slot";
			}
			$stmt->close();

		}
		// Close connection
		mysqli_close($link);
	}
?>
<html>
<head>
	<meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
	.page-header, .navbar{ font: 14px sans-serif; text-align: center; }
	
	.frm {
		font: 14px sans-serif;
		text-align: center;
	}
	
	.form-control{width: 11em;}
	
	.navbar {
	  overflow: hidden;
	  background-color: #333; 
	}

	.navbar a {
	  float: left;
	  font-size: 16px;
	  color: white;
	  text-align: center;
	  padding: 14px 16px;
	  text-decoration: none;
	}

	.subnav {
	  float: left;
	  overflow: hidden;
	}

	.subnav .subnavbtn {
	  font-size: 16px;  
	  border: none;
	  outline: none;
	  color: white;
	  padding: 14px 16px;
	  background-color: inherit;
	  font-family: inherit;
	  margin: 0;
	}

	.navbar a:hover, .subnav:hover .subnavbtn {
	  background-color: red;
	}

	.subnav-content {
	  display: none;
	  position: absolute;
	  left: 0;
	  background-color: red;
	  width: 100%;
	  z-index: 1;
	}

	.subnav-content a {
	  float: left;
	  color: white;
	  text-decoration: none;
	}

	.subnav-content a:hover {
	  background-color: #eee;
	  color: black;
	}

	.subnav:hover .subnav-content {
	  display: block;
	}

    </style>
</head>
<body>
	<div class="page-header">
		<h2>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?>. Select your date and time of booking</h2>
	</div>
	
	<div class="navbar">
	  <a href="calendar.php">Calendar</a>
	  <a href="welcome.php">Home</a>
	  <a href="myAccount.php">My Account</a>
	</div>
	
    <form action="<?=$_SERVER['PHP_SELF']?>" method="post" class='frm'>
	
		<div class="form-group <?php echo (!empty($room_err)) ? 'has-error' : ''; ?>">
		<img src="assets/floor1.jpg" alt="Floor 1" width="700px" height="405px" usemap="#rooms" name='rooms'>
		<map name="rooms" class="rooms">
			<area class="1.06" alt="1.06" title="1.06" coords="7,5,85,76" shape="rect" href="javascript:void(0)" onclick="<? echo $room = '1.06';?>"> 
			<area target="" alt="1.04" title="1.04" href="" coords="87,5,154,74" shape="rect">
			<area target="" alt="1.03" title="1.03" href="" coords="97,109,153,179" shape="rect">
			<area target="" alt="1.09" title="1.09" href="" coords="196,5,275,51" shape="rect">
			<area target="" alt="1.10" title="1.10" href="" coords="196,55,275,108" shape="rect">
			<area target="" alt="1.11" title="1.11" href="" coords="279,55,358,108" shape="rect">
			<area target="" alt="1.12" title="1.12" href="" coords="279,4,358,51" shape="rect">
			<area target="" alt="1.13" title="1.13" href="" coords="486,4,566,51" shape="rect"> 
			<area target="" alt="1.14" title="1.14" href="" coords="485,55,566,108" shape="rect">
			<area target="" alt="1.15" title="1.15" href="" coords="569,55,649,108" shape="rect">
			<area target="" alt="1.16" title="1.16" href="" coords="569,5,651,51" shape="rect">
			<area target="" alt="1.17" title="1.17" href="" coords="575,132,650,189" shape="rect">
			<area target="" alt="1.18" title="1.18" href="" coords="574,193,648,253" shape="rect">
			<area target="" alt="1.19" title="1.19" href="" coords="548,279,649,337" shape="rect">
			<area target="" alt="1.20" title="1.20" href="" coords="548,341,648,400" shape="rect">
			<area target="" alt="1.02" title="1.02" href="" coords="196,132,274,177" shape="rect">
			<area target="" alt="1.01" title="1.01" href="" coords="237,315,65" shape="circle">
			<input type='hidden' name="room" class="form-control" value="1.06"></input>
			<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js'></script>
			<script>
				function saveValue(roomNum) {
					$.ajax({
						url: 'saveValue.php',
						type: 'post',
						data: { "room": roomNum},
						success: function(response) { alert(response); }
					});
				}
			</script>
		</map>
		
		</div>
	
		<div class="form-group <?php echo (!empty($date_err)) ? 'has-error' : ''; ?>">
			<label>Date: <input type='date' list="bookDate" name='date' class="form-control" value="<?php echo $date; ?>"></input></label>
			
			<span class="help-block"><?php echo $date_err; ?></span>
		</div>
		
		<div id ='times' class="form-group <?php echo (!empty($startTime_err)) || (!empty($endTime_err)) ? 'has-error' : ''; ?>">
		
			<label>Time: Start:&nbsp </label>
			<select class ='start' name='start'>
				<option value="">Select Start Time</option>
				<option value="09:00:00">9am</option>
				<option value="10:00:00">10am</option>
				<option value="11:00:00">11am</option>
				<option value="12:00:00">12pm</option>
				<option value="13:00:00">1pm</option>
				<option value="14:00:00">2pm</option>
				<option value="15:00:00">3pm</option>
				<option value="16:00:00">4pm</option>
				<option value="17:00:00">5pm</option>
				<option value="18:00:00">6pm</option>
				<option value="19:00:00">7pm</option>
			</select>
			
			<label>&nbsp To: &nbsp </label>
			<select class ='end' name='end'>
				<option value="">Select Start Time</option>
				<option value="11:00:00">11am</option>
				<option value="12:00:00">12pm</option>
				<option value="13:00:00">1pm</option>
				<option value="14:00:00">2pm</option>
				<option value="15:00:00">3pm</option>
				<option value="16:00:00">4pm</option>
				<option value="17:00:00">5pm</option>
				<option value="18:00:00">6pm</option>
				<option value="19:00:00">7pm</option>
				<option value="20:00:00">8pm</option>
				<option value="21:00:00">9pm</option>
			</select>
			<span class="help-block"><?php echo $startTime_err; ?></span>
			<span class="help-block"><?php echo $endTime_err; ?></span>
			
		</div>
		
		<div class="form-group <?php echo (!empty($uni_err)) ? 'has-error' : ''; ?>">
			<label>University: </label> 
			<select class ='uni' name='uni'>
				<option value="">Select University</option>
				<option value="Latrobe University">Latrobe University</option>
				<option value="Western Sydney University">Western Sydney University</option>
			</select>
			<span class="help-block"><?php echo $uni_err; ?></span>
		</div>
		
		<input type='submit' value='Book room'>&nbsp
		<!--<input type="button" onclick="location.href='welcome.php';" value="Go Home" />-->
		<br>
		<div>
			<span class="help-block"><?php echo $msg; ?></span>
		</div>
		
	</form>
	

</body>
</html>