<?php

	function roomNum($room) {
		return $room;
		echo $room;
	}

	if(isset($_POST['room'])) {
		echo roomNum($_POST['room']);
	}
?>