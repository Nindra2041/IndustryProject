<?php
// Initialize the session
session_start();

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

require_once "config.php";

$sql = "SELECT username, personalEmail FROM users where username = ?";
$stmt = mysqli_prepare($link, $sql);
$stmt->bind_param("s", $_SESSION['username']);

$username = null;
$email = null;

if($stmt->execute()) {
  $stmt->store_result();
  mysqli_stmt_bind_result($stmt, $username, $email);
  mysqli_stmt_fetch($stmt);
  if($username != $_SESSION["username"]) {
    throw new \Exception("Error Processing Request", 1);
  }
  $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }

		.navbar {
	  overflow: hidden;
	  background-color: #333;
	}

	.navbar a {
	  float: left;
	  font-size: 16px;
	  color: white;
	  text-align: center;
	  padding: 14px 16px;
	  text-decoration: none;
	}

	.subnav {
	  float: left;
	  overflow: hidden;
	}

	.subnav .subnavbtn {
	  font-size: 16px;
	  border: none;
	  outline: none;
	  color: white;
	  padding: 14px 16px;
	  background-color: inherit;
	  font-family: inherit;
	  margin: 0;
	}

	.navbar a:hover, .subnav:hover .subnavbtn {
	  background-color: red;
	}

	.subnav-content {
	  display: none;
	  position: absolute;
	  left: 0;
	  background-color: red;
	  width: 100%;
	  z-index: 1;
	}

	.subnav-content a {
	  float: left;
	  color: white;
	  text-decoration: none;
	}

	.subnav-content a:hover {
	  background-color: #eee;
	  color: black;
	}

	.subnav:hover .subnav-content {
	  display: block;
	}

    </style>
</head>
<body>

  <div class="page-header">
		<h2>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?>. This is your account.</h2>
	</div>

	<div class="navbar">
	  <!--<a href="calendar.php">Calendar</a>-->
    <a href="welcome.php">Home</a>
	  <a href="bookRoom.php">Book a room</a>
	</div>

	<div style="padding:0 16px">
	</div>

    <p>Username: <?php echo htmlspecialchars($_SESSION["username"]); ?></p>
    <p>Email: <?php echo $email ?></p>

    <a href="javascript:void(0)" id="update" onclick="updatePass()">Change Password</a>
    <div id="upd" hidden='true'>
      <div class="newPass">
          <label>New Password</label>
          <input type="password" name="password" id="newPass" onkeyup="checkVals()">
      </div>
      <div class="newPass">
          <label>Confirm Password</label>
          <input type="password" name="password" id="confPass" onkeyup="checkVals()">
      </div>
      <button onclick="changePass()" disabled="true" id="btnUpdate">Change Password</button>
    </div>

    <p id="error" style="color:red"><p>

	<p>
        <a href="logout.php" class="btn btn-danger">Sign Out</a>
    </p>

    <script src="//cdnjs.cloudflare.com/ajax/libs/socket.io/1.7.4/socket.io.min.js"></script>
  	<script src="https://code.jquery.com/jquery-1.11.1.js"></script>
  	<script>
      var session = "<?php echo htmlspecialchars($_SESSION['username']); ?>";
      //socket = io.connect('//10.4.155.190:3000');
      socket = io.connect('//localhost:3000');
      socket.on('connect', function () {
  		   console.log('connected');
		  });

      function checkVals() {
        document.getElementById("error").innerHTML = "";
        if(document.getElementById("newPass").value != "" && document.getElementById("confPass").value != "") {
          document.getElementById("btnUpdate").disabled = false;
        } else {
          document.getElementById("btnUpdate").disabled = true;
        }
      }

      function changePass() {
        if(document.getElementById("newPass").value == document.getElementById("confPass").value) {
          if(document.getElementById("newPass").value.length >= 6) {
            socket.emit("updatePassword", session, document.getElementById("newPass").value);
            document.getElementById("error").innerHTML = "Password changed successfully";
            document.getElementById("error").style.color = "#00C42B";
            document.getElementById("upd").style.display = 'none';
            document.getElementById("upd").hidden = true;
            document.getElementById("update").hidden = false;
          } else {
            document.getElementById("error").innerHTML = "Password needs to have at least 6 characters";
          }
        } else {
          document.getElementById("error").innerHTML = "Passwords do not match";
        }
      }

      function updatePass() {
        document.getElementById("upd").style.display = 'inline';
        document.getElementById("upd").hidden = false;
        document.getElementById("update").hidden = true;
      }
    </script>
</body>
</html>
