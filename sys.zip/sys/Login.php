<?php

session_start();


if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){

    header("location: welcome.php");
    exit;
}


require_once "config.php";


$personalEmail = $password = "";
$personalEmail_err = $password_err = "";
$username = $username = "";
$adminLevel = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){


    if(empty(trim($_POST["personalEmail"]))){
        $personalEmail_err = "Please enter Email.";
    } else{
        $personalEmail = trim($_POST["personalEmail"]);
    }


    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }

    if(empty($personalEmail_err) && empty($password_err)){

        $sql = "SELECT personalEmail, password, username, adminLevel FROM users WHERE personalEmail = ? AND password = ?";

        if($stmt = mysqli_prepare($link, $sql)){

            mysqli_stmt_bind_param($stmt, "ss", $param_personalEmail, $param_password);



            $param_personalEmail = $personalEmail;
			$param_password = $password;
			$q = $param_password == $password;


            if(mysqli_stmt_execute($stmt)){

                mysqli_stmt_store_result($stmt);


                if(mysqli_stmt_num_rows($stmt) == 1){

                    mysqli_stmt_bind_result($stmt, $personalEmail, $password, $username, $adminLevel);//, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        //if(password_verify($password, $param_password)){//, $hashed_password)){
						        if($q == 1) {
                            // Password is correct, so start a new session
                            session_start();

                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["username"] = $username;
                            $_SESSION["personalEmail"] = $personalEmail;

                            // Redirect user to welcome page
                            header("location: welcome.php");
                            //admin levl
                            /*if($adminLevel == "1") {

                            } else if($adminLevel == "2") {

                            } else {

                            }*/

                        } else{
                            // Display an error message if password is not valid
                            $password_err = "The password you entered was not valid. $password $q";
                        }
                    }
                } else{
                    // Display an error message if personalEmail doesn't exist
                    //$personalEmail_err = "No account found with that personalEmail. $personalEmail";
					$personalEmail_err = "Account: $personalEmail does not exist with that password";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

			// Close statement
			mysqli_stmt_close($stmt);

        }
    }

    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 400px;
	margin: 10px auto;
	border: 2px solid #4CAF50;
	border-radius: 10px;
	padding: 30px;
	text-align: center; }

    @media screen and (max-width: 100px) {
  span.psw {
     display: block;
     float: none;
   }


     @media screen and (max-width: 100px) {
  span.psw {
     float: none;
     }
   }

    </style>
    <h2 align = "center";>Wellcome to Navitas Booking System</h2>
</head>
<body>
    <div class="wrapper">
    <img src="assets/navitaslogo.JPG" alt="Avatar" class="avatar" width="350px" height="150px">
        <p>Please fill in your credentials to login.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group <?php echo (!empty($personalEmail_err)) ? 'has-error' : ''; ?>">
                <label>Email</label>
                <input type="text" name="personalEmail" class="form-control" value="<?php echo $personalEmail; ?>">
                <span class="help-block"><?php echo $personalEmail_err; ?></span>
            </div>
            <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                <label>Password</label>
                <input type="password" name="password" class="form-control">
                <span class="help-block"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Login">
            </div>
           <p>Don't have an account? <a href="Signup.php">Sign up now</a> </p>
        </form>
    </div>
</body>
</html>
