<?php

	session_start();

	if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
		header("location: ../login.php");
		exit;
	}
	require_once "../assets/SysFunc/config.php";

	$date = "";
	$date_err = "";

	$stime = "";
	$startTime = "";
	$startTime_err = "";

	$etime = "";
	$endTime = "";
	$endTime_err = "";

	$uni = "";
	$uni_err = "";

	$room = "";

	$msg = "";

	if($_SERVER["REQUEST_METHOD"] == "POST"){

		if(empty($_POST["date"])){
			$date_err = "Please enter date of booking.";
		} else{
			$date = date('Y-m-d', strtotime($_POST['date']));
		}

		if($_POST["start"] == "" && $_POST["end"] == "") {//both empty
			$startTime_err = "Please enter start and end times for your booking";
		//check if each variable has a value
		} else {
			if($_POST["start"] == ""){//start is empty, end has a value
				$startTime_err = "Please enter start time of booking.";
			} else {
				$stime = $_POST['start'];
				$startTime = "$date $stime";
			}
			//end is empty, start has a value
			if($_POST["end"] == ""){
				$endTime_err = "Please enter end time of booking.";
			} else{
				$etime = $_POST['end'];
				$endTime = "$date $etime";
			}
		}

		if($_POST["uni"] == ""){
			$uni_err = "Please enter the university.";
		} else{
			$uni = $_POST['uni'];
		}

		// Validate credentials
		if(empty($date_err) && empty($startTime_err) && empty($endTime_err) && empty($uni_err)){

			$result = mysqli_query($link, "select bookedRoom from roomCheck order by bookedRoom desc limit 1");
    	if(mysqli_num_rows($result) > 0) {
     		$row = mysqli_fetch_assoc($result);
      	$room = $row['bookedRoom'];
    	}

			// Prepare a select statement
			$sql = "insert into booking values(?, ?, ? ,?, ?, ?)";
			$stmt = mysqli_prepare($link, $sql);
			$stmt->bind_param("ssssss", $_SESSION['username'], $date, $startTime, $endTime, $uni, $room);

			if($stmt->execute()){
				$msg = "Room booked.";
			} else{
				$msg = "ERROR: room could not be booked, there is already a room booked in this time slot";
			}
			$stmt->close();

		}
		// Close connection
		mysqli_close($link);
		header("location: welcome.php");
	}
?>
<html>
<head>
	<meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
	.page-header, .navbar{ font: 14px sans-serif; text-align: center; }

	.frm {
		font: 14px sans-serif;
		text-align: center;
	}

	.form-control{width: 11em;}

	.navbar {
	  overflow: hidden;
	  background-color: #333;
	}

	.navbar a {
	  float: left;
	  font-size: 16px;
	  color: white;
	  text-align: center;
	  padding: 14px 16px;
	  text-decoration: none;
	}

	.subnav {
	  float: left;
	  overflow: hidden;
	}

	.subnav .subnavbtn {
	  font-size: 16px;
	  border: none;
	  outline: none;
	  color: white;
	  padding: 14px 16px;
	  background-color: inherit;
	  font-family: inherit;
	  margin: 0;
	}

	.navbar a:hover, .subnav:hover .subnavbtn {
	  background-color: red;
	}

	.subnav-content {
	  display: none;
	  position: absolute;
	  left: 0;
	  background-color: red;
	  width: 100%;
	  z-index: 1;
	}

	.subnav-content a {
	  float: left;
	  color: white;
	  text-decoration: none;
	}

	.subnav-content a:hover {
	  background-color: #eee;
	  color: black;
	}

	.subnav:hover .subnav-content {
	  display: block;
	}

    </style>
</head>
<body>
	<div class="page-header">
		<h2>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?>. Select your date and time of booking</h2>
	</div>

	<div class="navbar">
	  <!--<a href="calendar.php">Calendar</a>-->
	  <a href="welcome.php">Home</a>
	  <a href="myAccount.php">My Account</a>
	</div>

    <form action="<?=$_SERVER['PHP_SELF']?>" method="post" class='frm'>

		<div class="form-group" id="floor">
			<p id="roomStatus" class="roomStatus">&nbsp</p>

			<img src="../assets/floorPlans/floor1.jpg" alt="Floor 1" width="700px" height="405px" usemap="#floor1" name='floor1' hidden="true" id='floor1'>
			<map name="floor1" class="floor1" hidden="true" id='floor1'>
    		<area target="" alt="1.01" title="1.01" href="javascript:void(0)" coords="464,387,298,267" shape="rect" onclick="assignRoom('1.01')">
    		<area target="" alt="1.02" title="1.02" href="javascript:void(0)" coords="313,199,382,243" shape="rect" onclick="assignRoom('1.02')">
    		<area target="" alt="1.03" title="1.03" href="javascript:void(0)" coords="131,147,249,232" shape="rect" onclick="assignRoom('1.03')">
    		<area target="" alt="1.04" title="1.04" href="javascript:void(0)" coords="128,6,252,95" shape="rect" onclick="assignRoom('1.04')">
    		<area target="" alt="1.06" title="1.06" href="javascript:void(0)" coords="7,6,125,94" shape="rect" onclick="assignRoom('1.06')">
    		<area target="" alt="1.09" title="1.09" href="javascript:void(0)" coords="314,5,381,87" shape="rect" onclick="assignRoom('1.09')">
    		<area target="" alt="1.10" title="1.10" href="javascript:void(0)" coords="314,90,381,167" shape="rect" onclick="assignRoom('1.10')">
    		<area target="" alt="1.11" title="1.11" href="javascript:void(0)" coords="385,90,451,167" shape="rect" onclick="assignRoom('1.11')">
    		<area target="" alt="1.12" title="1.12" href="javascript:void(0)" coords="385,6,452,86" shape="rect" onclick="assignRoom('1.12')">
    		<area target="" alt="1.13" title="1.13" href="javascript:void(0)" coords="510,6,575,88" shape="rect" onclick="assignRoom('1.13')">
    		<area target="" alt="1.14" title="1.14" href="javascript:void(0)" coords="510,92,576,166" shape="rect" onclick="assignRoom('1.14')">
    		<area target="" alt="1.15" title="1.15" href="javascript:void(0)" coords="579,92,646,168" shape="rect" onclick="assignRoom('1.15')">
    		<area target="" alt="1.16" title="1.16" href="javascript:void(0)" coords="579,6,645,89" shape="rect" onclick="assignRoom('1.16')">
    		<area target="" alt="1.17" title="1.17" href="javascript:void(0)" coords="547,187,648,232" shape="rect" onclick="assignRoom('1.17')">
    		<area target="" alt="1.18" title="1.18" href="javascript:void(0)" coords="547,234,647,282" shape="rect" onclick="assignRoom('1.18')">
    		<area target="" alt="1.19" title="1.19" href="javascript:void(0)" coords="531,293,648,339" shape="rect" onclick="assignRoom('1.19')">
    		<area target="" alt="1.20" title="1.20" href="javascript:void(0)" coords="532,344,647,388" shape="rect" onclick="assignRoom('1.20')">
			</map>

			<img src="../assets/floorPlans/floor2.jpg" alt="Floor 2" width="700px" height="405px" usemap="#floor2" name='floor2' hidden="true" id='floor2'>
			<map name="floor2" class='floor2' hidden="true" id='floor2'>
    		<area target="" alt="2.01" title="2.01" href="javascript:void(0)" coords="313,354,397,398" shape="rect" onclick="assignRoom('2.01')">
    		<area target="" alt="2.02" title="2.02" href="javascript:void(0)" coords="311,302,399,352" shape="rect" onclick="assignRoom('2.02')">
    		<area target="" alt="2.03" title="2.03" href="javascript:void(0)" coords="311,193,377,253" shape="rect" onclick="assignRoom('2.03')">
    		<area target="" alt="2.04" title="2.04" href="javascript:void(0)" coords="313,136,374,191" shape="rect" onclick="assignRoom('2.04')">
    		<area target="" alt="2.07" title="2.07" href="javascript:void(0)" coords="129,6,251,93" shape="rect" onclick="assignRoom('2.07')">
    		<area target="" alt="2.08" title="2.08" href="javascript:void(0)" coords="7,6,125,93" shape="rect" onclick="assignRoom('2.07')">
    		<area target="" alt="2.12" title="2.12" href="javascript:void(0)" coords="312,80,375,131" shape="rect" onclick="assignRoom('2.12')">
    		<area target="" alt="2.13" title="2.13" href="javascript:void(0)" coords="313,21,375,75" shape="rect" onclick="assignRoom('2.13')">
    		<area target="" alt="2.14" title="2.14" href="javascript:void(0)" coords="378,21,442,76" shape="rect" onclick="assignRoom('2.14')">
    		<area target="" alt="2.15" title="2.15" href="javascript:void(0)" coords="378,79,440,132" shape="rect" onclick="assignRoom('2.15')">
    		<area target="" alt="2.16" title="2.16" href="javascript:void(0)" coords="529,80,594,133" shape="rect" onclick="assignRoom('2.16')">
    		<area target="" alt="2.17" title="2.17" href="javascript:void(0)" coords="530,22,594,76" shape="rect" onclick="assignRoom('2.17')">
    		<area target="" alt="2.18" title="2.18" href="javascript:void(0)" coords="596,22,659,77" shape="rect" onclick="assignRoom('2.18')">
    		<area target="" alt="2.19" title="2.19" href="javascript:void(0)" coords="597,81,659,131" shape="rect" onclick="assignRoom('2.19')">
    		<area target="" alt="2.20" title="2.20" href="javascript:void(0)" coords="597,136,659,223" shape="rect" onclick="assignRoom('2.20')">
    		<area target="" alt="2.21" title="2.21" href="javascript:void(0)" coords="573,254,658,300" shape="rect" onclick="assignRoom('2.21')">
    		<area target="" alt="2.22" title="2.22" href="javascript:void(0)" coords="574,304,658,349" shape="rect" onclick="assignRoom('2.22')">
    		<area target="" alt="2.23" title="2.23" href="javascript:void(0)" coords="574,353,659,398" shape="rect" onclick="assignRoom('2.23')">
			</map>

			<img src="../assets/floorPlans/floor3.jpg" alt="Floor 3" width="700px" height="405px" usemap="#floor3" name='floor3' hidden="true" id='floor3'>
			<map name="floor3" class='floor3' hidden="true" id='floor3'>
    		<area target="" alt="3.01" title="3.01" href="javascript:void(0)" coords="55,7,144,50" shape="rect" onclick="assignRoom('3.01')">
    		<area target="" alt="3.02" title="3.02" href="javascript:void(0)" coords="55,54,143,96" shape="rect" onclick="assignRoom('3.02')">
    		<area target="" alt="3.03" title="3.03" href="javascript:void(0)" coords="56,101,142,142" shape="rect" onclick="assignRoom('3.03')">
    		<area target="" alt="3.06" title="3.06" href="javascript:void(0)" coords="147,100,240,141" shape="rect" onclick="assignRoom('3.06')">
    		<area target="" alt="3.07" title="3.07" href="javascript:void(0)" coords="147,7,238,96" shape="rect" onclick="assignRoom('3.07')">
    		<area target="" alt="3.09" title="3.09" href="javascript:void(0)" coords="277,96,363,141" shape="rect" onclick="assignRoom('3.09')">
    		<area target="" alt="3.11" title="3.11" href="javascript:void(0)" coords="392,160,460,244" shape="rect" onclick="assignRoom('3.11')">
    		<area target="" alt="3.12" title="3.12" href="javascript:void(0)" coords="366,101,459,141" shape="rect" onclick="assignRoom('3.12')">
    		<area target="" alt="3.13" title="3.13" href="javascript:void(0)" coords="366,54,460,97" shape="rect" onclick="assignRoom('3.13')">
    		<area target="" alt="3.14" title="3.14" href="javascript:void(0)" coords="367,5,461,51" shape="rect" onclick="assignRoom('3.14')">
    		<area target="" alt="3.15" title="3.15" href="javascript:void(0)" coords="514,314,587,398" shape="rect" onclick="assignRoom('3.15')">
    		<area target="" alt="3.16" title="3.16" href="javascript:void(0)" coords="514,201,586,287" shape="rect" onclick="assignRoom('3.16')">
    		<area target="" alt="3.17" title="3.17" href="javascript:void(0)" coords="590,202,659,285" shape="rect" onclick="assignRoom('3.17')">
    		<area target="" alt="3.18" title="3.18" href="javascript:void(0)" coords="590,314,660,400" shape="rect" onclick="assignRoom('3.18')">
    		<area target="" alt="3.19" title="3.19" href="javascript:void(0)" coords="367,263,461,309" shape="rect" onclick="assignRoom('3.19')">
    		<area target="" alt="3.20" title="3.20" href="javascript:void(0)" coords="367,313,462,356" shape="rect" onclick="assignRoom('3.20')">
    		<area target="" alt="3.21" title="3.21" href="javascript:void(0)" coords="367,360,459,398" shape="rect" onclick="assignRoom('3.21')">
		</map>

		</div>

		<div class="form-group <?php echo (!empty($date_err)) ? 'has-error' : ''; ?>">
			<label>Date: <input type='date' list="bookDate" name='date' class="form-control" id='date' value="<?php echo $date; ?>" onchange="setVal()"></input></label>

			<span class="help-block"><?php echo $date_err; ?></span>
		</div>

		<div id ='times' class="form-group <?php echo (!empty($startTime_err)) || (!empty($endTime_err)) ? 'has-error' : ''; ?>">

			<label>Time: Start:&nbsp </label>
			<select class ='start' id='start' name='start' onchange="setVal()">
				<option value="">Select Start Time</option>
				<option value="09:00:00">9am</option>
				<option value="10:00:00">10am</option>
				<option value="11:00:00">11am</option>
				<option value="12:00:00">12pm</option>
				<option value="13:00:00">1pm</option>
				<option value="14:00:00">2pm</option>
				<option value="15:00:00">3pm</option>
				<option value="16:00:00">4pm</option>
				<option value="17:00:00">5pm</option>
				<option value="18:00:00">6pm</option>
				<option value="19:00:00">7pm</option>
			</select>

			<label>&nbsp To: &nbsp </label>
			<select class ='end' id='end' name='end' onchange="setVal()">
				<option value="">Select Start Time</option>
				<option value="11:00:00">11am</option>
				<option value="12:00:00">12pm</option>
				<option value="13:00:00">1pm</option>
				<option value="14:00:00">2pm</option>
				<option value="15:00:00">3pm</option>
				<option value="16:00:00">4pm</option>
				<option value="17:00:00">5pm</option>
				<option value="18:00:00">6pm</option>
				<option value="19:00:00">7pm</option>
				<option value="20:00:00">8pm</option>
				<option value="21:00:00">9pm</option>
			</select>
			<span class="help-block"><?php echo $startTime_err; ?></span>
			<span class="help-block"><?php echo $endTime_err; ?></span>

		</div>

		<div class="form-group <?php echo (!empty($uni_err)) ? 'has-error' : ''; ?>">
			<label>University: </label>
			<select class ='uni' id='uni' name='uni' onchange="setVal()">
				<option value="">Select University</option>
				<option value="Latrobe University">Floor 1: Latrobe University</option>
				<option value="Western Sydney University">Floor 2: Western Sydney University</option>
				<option value="Navitas">Floor 3: Navitas</option>
			</select>
			<span class="help-block"><?php echo $uni_err; ?></span>
		</div>

		<input type='submit' value='Book room' id="btnSubmit">&nbsp
		<!--<input type="button" onclick="location.href='welcome.php';" value="Go Home" />-->
		<br>
		<div>
			<span class="help-block"><?php echo $msg; ?></span>
		</div>

	</form>

	<script src="//cdnjs.cloudflare.com/ajax/libs/socket.io/1.7.4/socket.io.min.js"></script>
	<script src="https://code.jquery.com/jquery-1.11.1.js"></script>
	<script>
		var roomStatus;
		var socket;
		var session = "<?php echo htmlspecialchars($_SESSION['username']); ?>";
		document.onLoad = initialVar();
		function initialVar() {
			roomStatus = false;
			document.getElementById('btnSubmit').disabled = true;
			document.getElementById('btnSubmit').style.color = 'grey';
			//socket = io.connect('//10.4.153.80:3000');
			socket = io.connect('//localhost:3000');
			initDB();
			document.getElementById('floor').style.display = 'none';
		}

		function setVal() {
			//button enable/disable
			if(roomStatus == true && document.getElementById('date').value != "" && document.getElementById('start').value != "" && document.getElementById('end').value != "" && document.getElementById('uni').value != "") {
				document.getElementById('btnSubmit').disabled = false;
				document.getElementById('btnSubmit').style.color = 'black';
			}
			//floor1
			if(document.getElementById('uni').value == "Latrobe University") {
				document.getElementById('floor').style.display = 'inline';
				document.getElementById('floor1').hidden = false;
			} else {
				//document.getElementById('floor').style.display = 'none';
				document.getElementById('floor1').hidden = true;
			}
			//floor2
			if(document.getElementById('uni').value == "Western Sydney University") {
				document.getElementById('floor').style.display = 'inline';
				document.getElementById('floor2').hidden = false;
			} else {
				//document.getElementById('floor').style.display = 'none';
				document.getElementById('floor2').hidden = true;
			}
			//floor3
			if(document.getElementById('uni').value == "Navitas") {
				document.getElementById('floor').style.display = 'inline';
				document.getElementById('floor3').hidden = false;
			} else {
				//document.getElementById('floor').style.display = 'none';
				document.getElementById('floor3').hidden = true;
			}
		}

		function formatDate(date) {
    var d = new Date(date), month = '' + (d.getMonth() + 1), day = '' + d.getDate(), year = d.getFullYear();
    	if (month.length < 2) month = '0' + month;
    	if (day.length < 2) day = '0' + day;

    	return [year, month, day].join('-');
		}

		socket.on('connect', function () {
			console.log('connected');
		});

		function initDB() {

			socket.emit('createTmp', session);
		}
		//**do sql stuff**
		function assignRoom(room) {
			if(document.getElementById('date').value != "" && document.getElementById('start').value != "" && document.getElementById('end').value != "") {
				initDB();
				console.log('checking for room ' + room);

				var date = document.getElementById('date').value;
				formatDate(date);
				var startTime = date + " " + document.getElementById('start').value;
				var endTime = date + " " + document.getElementById('end').value;

				socket.emit("rooms check", room, date, startTime, endTime, session);
				socket.on("room", function(roomStat) {
					document.getElementById('roomStatus').innerHTML = roomStat;
					document.getElementById('roomStatus').style.fontSize = "20px";

					if(roomStat.includes("is booked.")) {
						roomStatus = false;
					} else {
						roomStatus = true;
					}
					setVal();
				});
			} else {
				document.getElementById('roomStatus').innerHTML = "Please choose a date and time";
				document.getElementById('roomStatus').style.fontSize = "20px";
			}
		}

		document.addEventListener('beforeunload', function(e) {
			socket.emit("clearRoomTemp");
		});

		/*function disconnect() {
			socket.on('disconnect', function () {
				console.log('disconnected');
			});
		}*/
	</script>

</body>
</html>
