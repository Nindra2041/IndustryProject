<?php

  session_start();

  if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ../login.php");
    exit;
  }
  require_once "../assets/SysFunc/config.php";

  $room = "";
  $date = "";
  $start = "";
  $feedback = "";

  if(isset($_GET['room'])) {
    $room = $_GET['room'];
  }

  if(isset($_GET['start'])) {
    $start = $_GET['start'];
  }

  if(isset($_GET['date'])) {
    //$date = date('Y-m-d', strtotime($_GET['date']));
    $date = $_GET['date'];
  }

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
	body{ font: 14px sans-serif; text-align: center; }

	.navbar {
	  overflow: hidden;
	  background-color: #333;
	}

	.navbar a {
	  float: left;
	  font-size: 16px;
	  color: white;
	  text-align: center;
	  padding: 14px 16px;
	  text-decoration: none;
	}

	.subnav {
	  float: left;
	  overflow: hidden;
	}

	.subnav .subnavbtn {
	  font-size: 16px;
	  border: none;
	  outline: none;
	  color: white;
	  padding: 14px 16px;
	  background-color: inherit;
	  font-family: inherit;
	  margin: 0;
	}

	.navbar a:hover, .subnav:hover .subnavbtn {
	  background-color: red;
	}

	.subnav-content {
	  display: none;
	  position: absolute;
	  left: 0;
	  background-color: red;
	  width: 100%;
	  z-index: 1;
	}

	.subnav-content a {
	  float: left;
	  color: white;
	  text-decoration: none;
	}

	.subnav-content a:hover {
	  background-color: #eee;
	  color: black;
	}

	.subnav:hover .subnav-content {
	  display: block;
	}

	th {
		background-color:#000;
		color:white;
	}

	td, th {
		padding:5px;
		border:1px solid #000;
	}

    </style>
</head>
<body>
	<div class="page-header">
		<h2>Please provide your feedback for room <?php echo htmlspecialchars($room); ?></h2>
	</div>

	<div class="navbar">
	  <a href="welcome.php">Home</a>
	  <a href="bookRoom.php">Book a room</a>
	  <a href="myAccount.php">My Account</a>
	</div>

  </br>
  <label>Enter your feedback here</label>
  <br>
    <textarea rows="4" cols="100" placeholder="Provide your feedback here" onkeyup="checkVal()" id="feedback" name="feedback"></textarea>
    </br></br>
    <button onclick="provideFeedback()" disabled="true" id="form">Send Feedback</button>
  </br>
  <p id="errMsg"></p>

  <script src="//cdnjs.cloudflare.com/ajax/libs/socket.io/1.7.4/socket.io.min.js"></script>
  <script src="https://code.jquery.com/jquery-1.11.1.js"></script>
  <script>

    var username = "<?php echo htmlspecialchars($_SESSION['username']); ?>";
    var room = "<?php echo htmlspecialchars($room); ?>";
    var date = "<?php echo htmlspecialchars($date); ?>";
    var time = "<?php echo htmlspecialchars($start); ?>";

    //socket = io.connect('//10.4.153.80:3000');
    socket = io.connect('//localhost:3000');
    socket.on('connect', function () {
       console.log('connected');
    });

    document.getElementById('form').disabled = true;
    document.getElementById('form').style.color = 'grey';

    function checkVal() {
      if(document.getElementById('feedback').value != "") {
        if(document.getElementById('feedback').value.length > 450) {
          document.getElementById('form').disabled = true;
          document.getElementById('form').style.color = 'grey';
          document.getElementById('errMsg').innerHTML = "Feedback too long, please shorten to 450 characters";
            } else {
              document.getElementById('form').disabled = false;
              document.getElementById('form').style.color = 'black';
              document.getElementById('errMsg').innerHTML = "";
            }
      } else {
        document.getElementById('form').disabled = true;
        document.getElementById('form').style.color = 'grey';
      }
    }

    function provideFeedback() {
      var feedback = document.getElementById('feedback').value;
      socket.emit("provideFeedback", username, room, date, time, feedback);
      document.location.href = "welcome.php";
    }

  </script>

</body>
</html>
