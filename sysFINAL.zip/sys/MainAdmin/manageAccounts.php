<?php

	session_start();

	if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ../login.php");
    exit;
	}
	require_once "../assets/SysFunc/config.php";

  $sql = "select * from users order by adminLevel asc";
  $stmt = mysqli_prepare($link, $sql);

  $bookings = null;
  $book = null;

  ?>
  <html>
  <head>
  <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
  body{ font: 14px sans-serif; text-align: center; }

  .navbar {
    overflow: hidden;
    background-color: #333;
  }

  .navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }

  .subnav {
    float: left;
    overflow: hidden;
  }

  .subnav .subnavbtn {
    font-size: 16px;
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
  }

  .navbar a:hover, .subnav:hover .subnavbtn {
    background-color: red;
  }

  .subnav-content {
    display: none;
    position: absolute;
    left: 0;
    background-color: red;
    width: 100%;
    z-index: 1;
  }

  .subnav-content a {
    float: left;
    color: white;
    text-decoration: none;
  }

  .subnav-content a:hover {
    background-color: #eee;
    color: black;
  }

  .subnav:hover .subnav-content {
    display: block;
  }

  th {
    background-color:#000;
    color:white;
  }

  td, th {
    padding:5px;
    border:1px solid #000;
  }

    </style>
  </head>
  <body>
  <div class="page-header">
    <h2>Welcome to NRAB <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Here is the latest feedback of the rooms.</h2>
  </div>

  <div class="navbar">
    <!--<a href="welcome.php">Home</a>-->
    <a href="welcome.php">Home</a>
    <a href="myAccount.php">My Account</a>
  </div>

  <div align='centre'>
    &nbsp
    <!--<label><?php echo htmlspecialchars($_SESSION["username"]);?>'s bookings</label>-->

  </div>

  <?php
  try {
    if($stmt->execute()) {
      $stmt->store_result();
      $variables = array();
      $data = array();
      $meta = $stmt->result_metadata();
      while($field = $meta->fetch_field()) {
        $variables[] = &$data[$field->name];
      }
      call_user_func_array(array($stmt, 'bind_result'), $variables);
      $i = 0;
      while($stmt->fetch()) {
        $bookings[$i] = array();
        $book[$i] = array();
        foreach($data as $k=>$v) {
          $bookings[$i][$k] = $v;
          $book[$i] = json_encode($bookings[$i]);
          $book[$i] = json_decode($book[$i], true);
        }

        $i++;
      }
      $userNo = 0;
      settype($userNo, "integer");
      $user = "";
      settype($user, "string");
      if(is_array($book) || is_object($book)) {
        echo "<table style='border:1px solid black; margin-left:auto; margin-right:auto; width:900px;'>
          <tr>
              <th> <font face='Arial'><b>Username</b></font> </th>
              <th> <font face='Arial'><b>Email</b></font> </th>
              <th> <font face='Arial'><b>User Level</b></font> </th>
              <th> <font face='Arial'><b>Update User Level</b></font> </th>
          </tr>";
        foreach($book as $key => $val) {
          echo '<tr>
            <td>'.$val['username'].'</td>
            <td>'.$val['personalEmail'].'</td>';
            if($val["adminLevel"] == 1) {
              echo '<td>Admin</td>';
            } elseif($val["adminLevel"] == 2) {
              echo '<td>University Admin</td>';
            } else {
              echo '<td>Lecturer</td>';
            }
            echo '<td>
            <select id='.$userNo.' onchange="updUser('.$userNo.')">
      				<option value="">Update User Level</option>
      				<option value="1">Admin</option>
      				<option value="2">Uni Admin</option>
              <option value="3">Lecturer</option>
      			</select></td>
            </tr>';
            $userNo++;
          }

      } else {
        echo "<h2>No Users!</h2>";
      }
      $stmt->close();
    }
  } catch(Exception $e) {
    $bookings = false;
  }

  // Close connection
  mysqli_close($link);
  ?>

  <script src="//cdnjs.cloudflare.com/ajax/libs/socket.io/1.7.4/socket.io.min.js"></script>
  <script src="https://code.jquery.com/jquery-1.11.1.js"></script>
  <script>
		//socket = io.connect('//10.4.153.80:3000');
    socket = io.connect('//localhost:3000');
    socket.on('connect', function () {
      console.log('connected');
    });

    function updUser(userNo) {
      socket.emit("updateUser", userNo, document.getElementById(userNo).value);
      location.reload();
    }
  </script>
  </body>
  </html>
