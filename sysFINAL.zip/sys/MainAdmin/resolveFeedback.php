<?php
// Initialize the session
session_start();

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ../login.php");
    exit;
}

require_once "../assets/SysFunc/config.php";

$user = "";
$room = "";
$date = "";

if(isset($_GET['user'])) {
  $user = $_GET['user'];
}

if(isset($_GET['room'])) {
  $room = $_GET['room'];
}

if(isset($_GET['time'])) {
  //$date = date('Y-m-d', strtotime($_GET['date']));
  $date = $_GET['time'];
}

$sql = "Delete from Feedback where username = ? and room = ? and startTime = ?";
$stmt = mysqli_prepare($link, $sql);
$stmt->bind_param("sss", $user, $room, $date);

$stmt->execute();

$stmt->close();

mysqli_close($link);

header("location: welcome.php");
 ?>
